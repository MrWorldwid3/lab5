<html>
  <header>
    <meta charset="utf-8" />
  	<link href="lab1.css" rel="stylesheet" type="text/css" />
  </header>
  <body>
    <div class="responsive-menu">
      <ul>
        <li>  <a class="MenuHover <?php echo ($current_page == 'lab1.php' || $current_page == '') ? 'selected' : NULL ?>" href="lab1.php">
             Home
              </a>
        </li>
        <li>  <a class="MenuHover <?php echo ($current_page == 'AboutUs.php') ? 'selected' : NULL ?>" href="AboutUs.php">
             AboutUs
          </a>
        </li>
        <li>  <a class="MenuHover <?php echo ($current_page == 'BrowseBooks.php') ? 'selected' : NULL ?>" href="BrowseBooks.php">
             BrowseBooks
          </a>
        </li>
        <li>  <a class="MenuHover <?php echo ($current_page == 'MyBooks.php') ? 'selected' : NULL ?>" href="MyBooks.php">
             MyBooks
          </a>
        </li>
        <li>  <a class="MenuHover <?php echo ($current_page == 'Gallery.php' || $current_page == '') ? 'selected' : NULL ?>" href="Gallery.php">
             Gallery
              </a>
        </li>
        <li>  <a class="MenuHover <?php echo ($current_page == 'Contact.php') ? 'selected' : NULL ?>" href="Contact.php">
             Contact
          </a>
        </li>
        <li>  <a class="MenuHover <?php echo ($current_page == 'SQLInjection.php') ? 'selected' : NULL ?>" href="SQLInjection.php">
             Login
          </a>
        </li>
  </ul>
   </div>
