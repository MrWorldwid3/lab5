<?php
include("PHP_files/config.php");
include("header.php");

?>
  <head>
  <title>Lab_1</title>
  <meta charset="utf-8" />
	<link href="lab1.css" rel="stylesheet" type="text/css" />
  <meta name="viewport" content="width=device-width, initial-scale=1">
  </head>
  <body>
    <div id="Container">

<!-- body content -->

    <div class="main" style="margin:50px">
      <div class="AboutUsContainer">
        <h2> ABOUT US </h2>
   <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus imperdiet,
   nulla et dictum interdum, nisi lorem egestas odio, vitae scelerisque enim ligula </p>

  <p>  venenatis dolor. Maecenas nisl est, ultrices nec congue eget, auctor vitae massa.
   Fusce luctus vestibulum augue ut aliquet. Mauris ante ligula, facilisis sed ornare eu, </p>

  <p>  lobortis in odio. Praesent convallis urna a lacus interdum ut hendrerit risus congue.
   Nunc sagittis dictum nisi, sed ullamcorper ipsum dignissim ac. In at libero sed nunc  </p>

   <p> venenatis imperdiet sed ornare turpis. Donec vitae dui eget tellus gravida venenatis.
   Integer fringilla congue eros non fermentum. Sed dapibus pulvinar nibh tempor porta. </p>

   <p> Cras ac leo purus. Mauris quis diam velit. </p>

<img src="images/AboutUs.jpg" alt="W3Schools.com" width="300px" height="200px">
      </div>
  </div>

<!-- FOOTER -->
<?php
include("footer.php");
?>
</div>

  </body>
</html>
