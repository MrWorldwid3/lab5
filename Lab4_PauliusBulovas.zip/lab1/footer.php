<html>
  <header>
    <meta charset="utf-8" />
  	<link href="lab1.css" rel="stylesheet" type="text/css" />
  </header>
  <body>
<footer>
  <hr>
  <p class="FooterText" style="margin-left: 50px;"> Copy rights belong to - Paulius Bulovas | 2017 09 11 <p>
</footer>



<!--
    <div id="footer">
      <p>Contact Us:</p> <br>
      <p> Telephone number: +46761057692 </p> <br>
      <p> Adress: Jönköping City, Odengatan 4; </p> <br>
    </div>
-->
