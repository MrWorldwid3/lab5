<?php
include("PHP_files/config.php");
include("header.php");

?>
  <head>
  <title>Lab_1</title>
  <meta charset="utf-8" />
	<link href="lab1.css" rel="stylesheet" type="text/css" />
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!--FOR IMG SLIDER -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600' rel='stylesheet' type='text/css'>
<link href="http://netdna.bootstrapcdn.com/font-awesome/3.1.1/css/font-awesome.css" rel="stylesheet">

 <script src="https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.5.8/angular.min.js"></script>

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  </head>
  <body>
    <div id="pagecontainer">

     <!--IMG SLIDER-->

		<div class="container">
  <br>
  <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
      <li data-target="#myCarousel" data-slide-to="3"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox">

      <div class="item active">
        <img src="images/book1.jpg" alt="Chania" class="slidepic" >
        <div class="carousel-caption">
          <h3 class="slidesheader">Regular library visits inevitably lead to more reading.</h3>
          <p class="sliderstext">And reading, as it turns out, is brain food!</p>
        </div>
      </div>

      <div class="item">
        <img src="images/book2.jpg" alt="Chania" class="slidepic" >
        <div class="carousel-caption">
          <h3 class="slidesheader">Library time is active, not passive.</h3>
          <p class="sliderstext">Spend your time wisely</p>
        </div>
      </div>

      <div class="item">
        <img src="images/book3.jpg" alt="Flower" class="slidepic" >
        <div class="carousel-caption">
          <h3 class="slidesheader"> There is no friend as loyal as a book</h3>
          <p class="sliderstext">Books are the key to finding your self</p>
        </div>
      </div>
       <div class="item">
        <img src="images/book4.jpg" alt="Flower" class="slidepic" >
        <div class="carousel-caption">
          <h3 class="slidesheader">Owning a library card teaches responsibility.</h3>
          <p class="sliderstext" >Treat books with care</p>
        </div>
      </div>


    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</div>		<h3 class="h333"> What Our Book Shop Is Offering </h2>

     <!-- MainContent (BODY) -->
     <div id="MainContent">
       <div>
         Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
       </div>
     </div>
      <!-- FOOTER -->
      <?php
      include("footer.php");

      ?>

    </div>

      <script src="script.js"> </script>
  </body>
</html>
