<?php
include("PHP_files/config.php");
include("header.php");

?>


<?php

  //connecting to the database called testinguser
  @ $db = new mysqli('localhost', 'root', '', 'testinguser');

  if(isset($_POST['username'], $_POST['userpass'])){
    // mysqli_real_escape_string makes inpossible to comment out the password
    $uname = mysqli_real_escape_string($db, $_POST['username']);
    $upass = sha1($_POST['userpass']);

    echo $uname;
    echo "</br>";
    echo $upass;

    //selecting a username and password from the database created in localPHPAdmin
    $query = ("SELECT * FROM user WHERE username = '{$uname}' "."AND userpass = '{$upass}'");

    // getting the query, executing it and storing the information
    $stmt = $db->prepare($query);
    $stmt->execute();
    $stmt->store_result();
    // if the number of rows are zero the password is incorrect if there is something in means
    //the pasword is matching
    $totalcount = $stmt->num_rows();

  }

 ?>


<!DOCTYPE html>

<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body>
      <?php
      //if there is something in totalcount we want to give the acced to the website
      // if the totalcount is == 0 then sorry it was the wrong uname and upass
      if(isset($totalcount)){
          if($totalcount == 0){

            echo "Wrong password";
          } else{

            // gives a link to upload Files
            echo "<a href=Lab4PHP/fileUpload.php> Welcome here is the link you need: </a>";
          }


      }

       ?>
        <form method="POST" action="">
            <input type="text" name="username">
            <input type="password" name="userpass">
            <input type="submit" value="Go">
        </form>

        <?php
        include("footer.php");

        ?>
    </body>
</html>
