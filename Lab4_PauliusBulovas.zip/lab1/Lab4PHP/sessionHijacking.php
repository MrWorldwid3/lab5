<?php
//1. cookies can only be access through php code
ini_set('session.cookie_httponly', true);

//Starts the session
session_start ();
//2. check if user ip that made the sesh is matching with the sesh so he could access the code
if (isset($_SESSION['userip']) === false){
  // here we store user ip to use it in the code for checking if it matches
  $_SESSION['userip'] = $_SERVER['REMOTE_ADDR'];

}
  // if the user id doesnt match we want to destroy the sesh and the user can feel safe
  if ($_SESSION['userip'] !== $_SERVER['REMOTE_ADDR']){

    session_unset();
    session_destroy();

  }


 ?>
