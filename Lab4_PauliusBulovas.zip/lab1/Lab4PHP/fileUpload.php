<?php
if (isset($_FILES['upload'])){
  //this only allows picture files to be uploaded
  $allowedextensions = array ('jpg', 'jpeg', 'gif', 'png');
  //Checking what kind of file it is
  $extension = strtolower(substr($_FILES['upload']['name'], strrpos($_FILES['upload']['name'], '.') +1 ));

  echo "Your file extension is: ".$extension;

  //to be more proffessional we create an array that store errors
  $error = array ();
  //Checks if the extension is allowed
  if(in_array($extension, $allowedextensions) === false){
    //if it is skip this if not do this
     $error[] = 'This is not an image, upload is allowed only for images. Thanks for cooperation.';
  }

    // Checking if the file does not exced 10mb size
  if($_FILES['upload'] ['size'] > 10000000){
    //if the file is not bigger than 10mb ignore this
    $errror[] = 'The file is to big. Files cannot exced 10mb.';

  }
  //if there is no error we want to do the upload
  if (empty($error)){

    //upload the file and take the name of it
    move_uploaded_file($_FILES['upload']['tmp_name'], "uploadedfiles/{$_FILES['upload']['name']}");

  }

}

?>
<html>
    <head>
        <title>Security - Upload</title>
           </head>

           <body>
             <?php

             if(isset($error)){

               if(empty($error)){
                 //Makes it possible to see the file just after the user uploaded it
                 echo '<a href="uploadedfiles/' . $_FILES['upload']['name'] . '">This is your file <3';

               }
               else{
                 foreach($error as $err){
                   echo $err;
                   echo '</br>';
                 }
               }

             }



              ?>
               <div>

                   <form action="" method="POST" enctype="multipart/form-data">
                       <input type="file" name="upload" /></br>
                       <input  type="submit" value="submit" />
                   </form>
               </div>
           </body>




</html>
