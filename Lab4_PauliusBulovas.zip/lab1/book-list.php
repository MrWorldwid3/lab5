<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#create an array of books
/*
$books = array(); #empty array to put elements in
$books[] = array("title" => "The Kite Runner (2009)", "author" => "Khaled Hosseini");
$books[] = array("title" => "Number the Stars", "author" => "Lois Lowry");
$books[] = array("title" => "Pride and Prejudice", "author" => "Jane Austen");
$books[] = array("title" => "Little Women", "author" => "Louisa May Alcott");
$books [] = array("title" => "Title", "author" => "authornumber4");
*/
$books = array();
$books [] = array("title" => "The Kite Runner", "author" => "Khaled Hosseini");
$books [] = array("title" => "Number the Stars", "author" => "Lois Lowry");
$books [] = array("title" => "Pride and Prejudice", "author" => "Jane Austen");
$books [] = array("title" => "Little Women", "author" => "Louisa May Alcott");





#print out the arrays in a table using HTML (you basically echo out HTML code, it works just fine!)

    /* echo '<table cellpadding="6">';
    echo '<tr><b><td>Title</td> <td>Author</td> <td>Reserve</td> </b> </tr>';

    if ($id !== FALSE) {
        $book = $books[$id];
        $title = $book['title'];
        $author = $book['author'];
        echo "<tr>";
        echo "<td> $title </td><td> $author </td>";
        echo '<td><a href="reserve.php?reservation=' .  urlencode($title) . '"> Reserve </a></td>';
        echo "</tr>";
    } else if ($auth !== FALSE) {
      $book = $books[$auth];
        $title = $book['title'];
        $author = $book['author'];
        echo "<tr>";
        echo "<td> $title </td><td> $author </td>";
        echo '<td><a href="reserve.php?reservation=' .  urlencode($author) . '"> Reserve </a></td>';
        echo "</tr>";
    }
    echo "</table>";
    */
