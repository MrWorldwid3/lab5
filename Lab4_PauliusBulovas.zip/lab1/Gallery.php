<?php
include("PHP_files/config.php");
include("header.php");

?>

<head>
<title>Lab_1</title>
<meta charset="utf-8" />
<link href="imgGallery.css" rel="stylesheet" type="text/css" />
</head>

<body>
  <div class="imgGallery">
<div><img src="Images/GalleryImages/bookcover1.jpg" alt></div>
<div><img src="Images/GalleryImages/bookcover2.jpg" alt></div>
<div><img src="Images/GalleryImages/bookcover3.jpg" alt></div>
<div><img src="Images/GalleryImages/bookcover4.jpg" alt></div>
<div><img src="Images/GalleryImages/bookcover5.jpg" alt></div>
  </div>

  <?php
$folder_path = 'Lab4PHP/uploadedfiles/'; //image's folder pathe


$num_files = glob($folder_path . "*.{JPG,jpg,gif,png,bmp}", GLOB_BRACE);

$folder = opendir($folder_path);

if($num_files > 0)
{
 while(false !== ($file = readdir($folder)))
 {
  $file_path = $folder_path.$file;
  $extension = strtolower(pathinfo($file ,PATHINFO_EXTENSION));
  if($extension=='jpg' || $extension =='png' || $extension == 'gif' || $extension == 'bmp')
  {
   ?>
            <a href="<?php echo $file_path; ?>"><img src="<?php echo $file_path; ?>"  height="250" /></a>
            <?php
  }
 }
}
else
{
 echo "the folder was empty !";
}
closedir($folder);
?>

  <?php
  include("footer.php");

  ?>
</body>
